

10.times do |x|
  result = "{\n  \"version\": \"VERSION 1.2\",\n  \"result\": [{\n      \"post_id\":\"post6374637\",\n      \"popularity_score\": #{(rand*10).round(4)}\n    },{\n      \"post_id\":\"post3637373\",\n      \"popularity_score\": #{(rand*10).round(4)}\n    },{\n      \"post_id\":\"post3637371\",\n      \"popularity_score\": #{(rand*10).round(4)}\n    },{\n      \"post_id\":\"post3637372\",\n      \"popularity_score\": #{(rand*10).round(4)}\n    },{\n      \"post_id\":\"post3637375\",\n      \"popularity_score\": #{(rand*10).round(4)}\n    },{\n      \"post_id\":\"post3637374\",\n      \"popularity_score\": #{(rand*10).round(4)}\n    }],\n  \"external_data\": {\n    \"used\": \"true\",\n    \"details\": \"VGG-19 pre-trained on ImageNet training set\"\n  }\n}"
  File.open("#{x}.json",'w') do |f|
    f.write(result)
  end
end