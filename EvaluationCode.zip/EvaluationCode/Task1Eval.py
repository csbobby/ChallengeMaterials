from scipy import stats
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
import json
import pandas as pd
import os
def evaluate(json_file_path,ground_truth_file):
  y_truth_postid = load_json_postid(ground_truth_file)
  y_pred_postid = load_json_postid(json_file_path)
  if y_truth_postid != y_pred_postid:
    print('\x1b[0;30;41m' + json_file_path + ':format error, post id is not correspond!' + '\x1b[0m')
    raise Exception('format error, post id is not correspond!')
  y_truth = load_json(ground_truth_file)
  y_pred = load_json(json_file_path)

  print("%d vs %d"%(len(y_truth),len(y_pred)))
  if len(y_truth)!=len(y_pred):
    print('\x1b[0;30;41m' + json_file_path + ':num of pred result incorrect!' + '\x1b[0m')
    raise Exception('num of pred result incorrect!')
  spearmanr_corr = stats.spearmanr(y_truth, y_pred)[0]
  mse=mean_squared_error(y_truth, y_pred)
  mae=mean_absolute_error(y_truth, y_pred)
  print('\x1b[6;30;42m' + "%s: SPEARMAN: %.4f, MSE: %.4f, MAE: %.4f"%(json_file_path,spearmanr_corr,mse,mae) + '\x1b[0m')



def load_json(json_file_path):
  json_str = open(json_file_path,'r').read()
  json_result = json.loads(json_str)['result']
  result = {"post_id":[],"popularity_score":[]}
  for row in json_result:
    result["post_id"].append(row["post_id"])
    result["popularity_score"].append(row["popularity_score"])
  dataframe = pd.DataFrame(result)
  return dataframe.sort_values('post_id')['popularity_score'].tolist()

def load_json_postid(json_file_path):
  json_str = open(json_file_path,'r').read()
  json_result = json.loads(json_str)['result']
  result = {"post_id":[],"popularity_score":[]}
  for row in json_result:
    result["post_id"].append(row["post_id"])
    result["popularity_score"].append(row["popularity_score"])
  dataframe = pd.DataFrame(result)
  return dataframe.sort_values('post_id')['post_id'].tolist()

# use this method as main method
# directory: a directory contains all candidates' json submission
# ground_truth_file: a json file contains the ground truth
def evaluate_jsons(directory,ground_truth_file):
  for filename in os.listdir(directory):
    if filename.endswith(".json"):
        json_file_path = (os.path.join(directory, filename))
        # evaluate(json_file_path,ground_truth_file)
        try:
          evaluate(json_file_path,ground_truth_file)
        except Exception as e:
          print(e)
        


# EXAMPLE USAGE
evaluate_jsons('../Data/Task1','../Data/T1Validation.json')
