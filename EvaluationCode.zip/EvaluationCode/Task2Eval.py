from scipy import stats
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
import json
import pandas as pd
import os

def calc_hit_rate(pred_df,truth_df,hit_top):
  pred_pids = set(pred_df.sort_values('ranking_position')['post_id'].tolist()[:hit_top])
  truth_pids = set(truth_df.sort_values('ranking_position')['post_id'].tolist()[:hit_top])
  intersection = len(pred_pids&truth_pids)
  return float(intersection)/float(hit_top)

def calc_mae(pred_df,truth_df):
  truth_pops = truth_df.sort_values('post_id')['popularity_score'].tolist()
  pred_pops = pred_df.sort_values('post_id')['popularity_score'].tolist()
  mae=mean_absolute_error(truth_pops, pred_pops)
  return mae

def calc_spearman(pred_df,truth_df):
  truth_pops = truth_df.sort_values('post_id')['popularity_score'].tolist()
  pred_pops = pred_df.sort_values('post_id')['popularity_score'].tolist()
  spearmanr_corr = stats.spearmanr(truth_pops, pred_pops)[0]
  return spearmanr_corr

#MHR, MAE, Spearmanr's Rho
def evaluate(json_file_path,ground_truth_file,hit_top=5):
  y_truth_postid = load_json_postid(ground_truth_file)
  y_pred_postid = load_json_postid(json_file_path)
  if set(y_truth_postid) != set(y_pred_postid):
    print('\x1b[0;30;41m' + json_file_path + ':format error, post id is not correspond!' + '\x1b[0m')
    raise Exception('format error, post id is not correspond!')
  pred_df = load_json(json_file_path)
  truth_df = load_json(ground_truth_file)
  print("%d vs %d"%(len(pred_df),len(truth_df)))
  if len(pred_df)!=len(truth_df):
    print('\x1b[0;30;41m' + json_file_path + ':num of pred result incorrect!' + '\x1b[0m')
    raise Exception('num of pred result incorrect!')
  
  hit_rate = calc_hit_rate(pred_df,truth_df,hit_top)
  mae = calc_mae(pred_df,truth_df)
  spearmanr = calc_spearman(pred_df,truth_df)
  print('\x1b[6;30;42m' + "%s: hit rate: %.4f, MAE: %.4f,Spearman: %.4f"%(json_file_path,hit_rate,mae,spearmanr) + '\x1b[0m')

def load_json(json_file_path):
  json_str = open(json_file_path,'r').read()
  json_result = json.loads(json_str)['result']
  result = {"post_id":[],"popularity_score":[],"ranking_position":[]}
  for row in json_result:
    result["post_id"].append(row["post_id"])
    result["popularity_score"].append(row["popularity_score"])
    result["ranking_position"].append(row["ranking_position"])
  dataframe = pd.DataFrame(result)
  return dataframe


def load_json_postid(json_file_path):
  json_str = open(json_file_path,'r').read()
  json_result = json.loads(json_str)['result']
  result = {"post_id":[],"popularity_score":[]}
  for row in json_result:
    result["post_id"].append(row["post_id"])
    result["popularity_score"].append(row["popularity_score"])
  dataframe = pd.DataFrame(result)
  return dataframe.sort_values('post_id')['post_id'].tolist()

# use this method as main method
# directory: a directory contains all candidates' json submission
# ground_truth_file: a json file contains the ground truth
def evaluate_jsons(directory,ground_truth_file):
  for filename in os.listdir(directory):
    if filename.endswith(".json"):
        try:
          json_file_path = (os.path.join(directory, filename))
          evaluate(json_file_path,ground_truth_file)
        except Exception as e:
          print(e)
        

# EXAMPLE USAGE
evaluate_jsons('../Data/Task2','../Data/T2Validation.json')